/**
 * Created by suh on 2015-04-01.
 */
abstract public class Activity {
    int key;
    protected String name = null;
}
