/**
 * Created by suh on 2015-04-01.
 */
//key : 7
public class Rotaract extends Club {
    int key = 7;
    Rotaract(){
        name = "로타랙트";
    }
}
