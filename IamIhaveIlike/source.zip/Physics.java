/**
 * Created by suh on 2015-04-01.
 */
//Key : 2
public class Physics extends Lectures {
    int key = 2;
    Physics(){
        name = "일반 물리학 및 실험";
    }
}
