/**
 * Created by suh on 2015-04-01.
 */
//Key : 6
public class UC extends Lectures {
    int key = 6;
    UC(){
        name = "컴퓨터의 이해";
    }
}
