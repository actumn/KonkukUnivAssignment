/**
 * Created by suh on 2015-04-01.
 */
public class Wed extends Days {
    Wed(){
        date = "������";
        this.time = 0;
        this.schedules = new Schedule[1];
        schedules[0] = new Schedule(4, 16, 2);
    }
}
