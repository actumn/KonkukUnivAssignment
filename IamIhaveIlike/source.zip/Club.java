/**
 * Created by suh on 2015-04-01.
 */
public class Club extends Activity {
}
