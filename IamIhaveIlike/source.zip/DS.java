/**
 * Created by suh on 2015-04-01.
 */
//Key : 4
public class DS extends Lectures {
    int key = 4;
    DS(){
        name = "자료 구조";
    }
}
