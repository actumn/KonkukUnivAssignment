/**
 * Created by suh on 2015-04-01.
 */
//Key : 5
public class CAA extends Lectures {
    int key = 5;
    CAA(){
        name = "컴퓨터 응용 및 실습";
    }
}