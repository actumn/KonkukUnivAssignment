/**
 * Created by suh on 2015-04-01.
 */
//Key : 3
public class PP extends Lectures {
    int key = 3;
    PP(){
        name = "프로그래밍 프로젝트";
    }
}
