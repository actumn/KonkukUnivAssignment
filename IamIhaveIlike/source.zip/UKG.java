/**
 * Created by suh on 2015-04-01.
 */
//Key : 1
public class UKG extends Lectures {
    int key = 1;
    UKG(){
        name = "한국 행정의 이해";
    }
}
